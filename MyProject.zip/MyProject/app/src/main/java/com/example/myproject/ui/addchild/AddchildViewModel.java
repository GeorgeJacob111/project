package com.example.myproject.ui.addchild;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AddchildViewModel extends ViewModel {
    private final MutableLiveData<String> mText;

    public AddchildViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is add child");
    }

    public LiveData<String> getText() {
        return mText;
    }
}