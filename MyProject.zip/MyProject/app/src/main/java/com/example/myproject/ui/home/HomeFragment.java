package com.example.myproject.ui.home;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.myproject.databinding.FragmentHomeBinding;
import com.example.myproject.ui.child_reg;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    FirebaseDatabase database;
    FirebaseAuth auth;
    DatabaseReference databaseReference;






    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        HomeViewModel homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("mineid", Context.MODE_PRIVATE);
        String id = sharedPreferences.getString("userid","");

        databaseReference = FirebaseDatabase.getInstance().getReference("users");

        Query check = databaseReference.orderByChild("userid").equalTo(id);
        Toast.makeText(this.requireContext(), id, Toast.LENGTH_SHORT).show();



        check.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.child("users").getValue(String.class);
                //binding.textViewChild4.setText(value);
                binding.textViewChild4.setText(new StringBuilder().append(value).append(".").toString());



//                if(snapshot.exists())
//                {
//                    String data = snapshot.child("pincode").getValue(String.class);
//                    binding.textViewChild4.setText(new StringBuilder().append(data).append(".").toString());
//                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(HomeFragment.this.requireContext(), "Fail to get data.", Toast.LENGTH_SHORT).show();


            }
        });




        binding.textViewChild5.setText(id);

        //button1
        binding.bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(HomeFragment.this.requireContext(),child_reg.class);
                i.putExtra("order","1");
                startActivity(i);
                //startActivity(new Intent(HomeFragment.this.requireContext(),child_reg.class));
            }
        });


        //button2
        binding.bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(HomeFragment.this.requireContext(),child_reg.class);
                i.putExtra("order","2");
                startActivity(i);
                //startActivity(new Intent(HomeFragment.this.requireContext(), child_reg.class));
            }
        });



        //button3

        binding.bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(HomeFragment.this.requireContext(),child_reg.class);
                i.putExtra("order","3");
                startActivity(i);
                //startActivity(new Intent(HomeFragment.this.requireContext(), child_reg.class));
            }
        });








        return root;
    }











    /*private void getdata() {

        // calling add value event listener method
        // for getting the values from database.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // this method is call to get the realtime
                // updates in the data.
                // this method is called when the data is
                // changed in our Firebase console.
                // below line is for getting the data from
                // snapshot of our database.
                String value = snapshot.getValue(String.class);

                // after getting the value we are setting
                // our value to our text view in below line.
                binding.textViewChild4.setText(value);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // calling on cancelled method when we receive
                // any error or we are not able to get the data.

            }
        });
    }*/
















    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}