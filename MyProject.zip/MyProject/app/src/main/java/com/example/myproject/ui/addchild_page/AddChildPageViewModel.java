package com.example.myproject.ui.addchild_page;

import androidx.lifecycle.ViewModel;

public class AddChildPageViewModel extends ViewModel {

}