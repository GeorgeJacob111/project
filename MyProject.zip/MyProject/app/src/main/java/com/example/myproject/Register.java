package com.example.myproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myproject.models.users;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Register extends AppCompatActivity {

    EditText username,address,phone,mail,passwd,pincode,landmark,dateofbirth;
    Button Register;
    TextView Signup;
    String inusername,inaddress,inphone,inmail,inpasswd,inpincode,inlandmark,indateofbirth;

    FirebaseAuth auth;
    FirebaseDatabase database;
    String profile = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        username = findViewById(R.id.Username);
        mail = findViewById(R.id.Email);
        passwd = findViewById(R.id.Password);
        address = findViewById(R.id.Address);
        phone = findViewById(R.id.Phone);
        pincode = findViewById(R.id.Pincode);
        landmark = findViewById(R.id.Landmark);
        dateofbirth = findViewById(R.id.Dateofbirth);

        //buttons
        Register = findViewById(R.id.Register);
        Signup = findViewById(R.id.signup);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        getSupportActionBar().hide();

        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Register.this,login.class));
            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inusername = username.getText().toString().trim();
                inmail = mail.getText().toString().trim();
                inpasswd = passwd.getText().toString().trim();
                inaddress = address.getText().toString().trim();
                inphone = phone.getText().toString().trim();
                inpincode = pincode.getText().toString().trim();
                inlandmark = landmark.getText().toString().trim();
                indateofbirth = dateofbirth.getText().toString().trim();

                Toast.makeText(Register.this, "user"+inusername+" mail"+inmail+" password"+inpasswd+" address"+inaddress+" phone"+inphone+" pin"+inpincode+" landmark"+inlandmark+" dateofbirth"+indateofbirth, Toast.LENGTH_SHORT).show();

                if (TextUtils.isEmpty(inusername) || inusername.length() < 3)
                { username.setError("username must be of 3 or more character");
                    Toast.makeText(Register.this, "Registerion failed username", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(inaddress) || inaddress.length() < 10) {
                    address.setError("Enter a valid address");
                    Toast.makeText(Register.this, "Registerion failed address", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(inphone) || inphone.length() < 10) {
                    phone.setError("Enter a valid phone number");
                    Toast.makeText(Register.this, "Registerion failed phone", Toast.LENGTH_SHORT).show();
                }
                else if (!validateEmail(mail, getString(R.string.lbl_null_value), getString(R.string.lbl_invalid_value))) {
                    Toast.makeText(Register.this, "Registerion failed mail", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(inpasswd) || inpasswd.length() < 6) {
                    passwd.setError("password should contain 6 or more character");
                    Toast.makeText(Register.this, "Registerion failed password", Toast.LENGTH_SHORT).show();
                }else if (TextUtils.isEmpty(inpincode) || inpincode.length() < 6) {
                    pincode.setError("enter a valid pincode");
                    Toast.makeText(Register.this, "Registerion failed pincode", Toast.LENGTH_SHORT).show();
                }else if (TextUtils.isEmpty(inlandmark) || inlandmark.length() < 3) {
                    landmark.setError("Enter a valid landmark");
                    Toast.makeText(Register.this, "Registerion failed landmark", Toast.LENGTH_SHORT).show();
                }else if (TextUtils.isEmpty(indateofbirth) || indateofbirth.length() < 10) {
                    dateofbirth.setError("Enter a valid DOB");
                    Toast.makeText(Register.this, "Registerion failed DateOfBirth", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Register.this, "all set", Toast.LENGTH_SHORT).show();
                    auth.createUserWithEmailAndPassword(inmail, inpasswd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            //database user creation
                            String status = new String();
                            status = "1";
                            String id = task.getResult().getUser().getUid();
                            users user = new users(inusername, inmail, inpasswd,id,status,inaddress,inphone,inpincode,inlandmark,indateofbirth);
                            Toast.makeText(Register.this, "id : " + id, Toast.LENGTH_SHORT).show();
                            database.getReference().child("users").child(id).setValue(user);
                            database.getReference().child("users").child(id).child("profilepic").setValue(profile);
                            database.getReference().child("users").child(id).child("emailvalidity").setValue(profile);

                            Toast.makeText(Register.this, "User Created", Toast.LENGTH_SHORT).show();
                        }
                    });

                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                }


            }
        });

    }

    private boolean validateEmail(EditText p_editText, String p_nullMsg, String p_invalidMsg) {
        boolean m_isValid = false;
        try {
            if (p_editText != null) {
                if (validateForNull(p_editText, p_nullMsg)) {
                    Pattern m_pattern = Pattern.compile("([\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Za-z]{2,4})");
                    Matcher m_matcher = m_pattern.matcher(p_editText.getText().toString().trim());
                    if (!m_matcher.matches() & p_editText.getText().toString().trim().length() > 0) {
                        m_isValid = false;
                        p_editText.setError(p_invalidMsg);
                    } else {
                        m_isValid = true;
                    }
                } else {
                    m_isValid = false;
                }
            } else {
                m_isValid = false;
            }
        } catch (Throwable p_e) {
            p_e.printStackTrace();
        }
        return m_isValid;
    }

    private boolean validateForNull(EditText p_editText, String p_nullMsg) {
        boolean m_isValid = false;
        try {
            if (p_editText != null && p_nullMsg != null) {
                if (TextUtils.isEmpty(p_editText.getText().toString().trim())) {
                    p_editText.setError(p_nullMsg);
                    m_isValid = false;
                } else {
                    m_isValid = true;
                }
            }
        } catch (Throwable p_e) {
            p_e.printStackTrace();
        }
        return m_isValid;
    }


}