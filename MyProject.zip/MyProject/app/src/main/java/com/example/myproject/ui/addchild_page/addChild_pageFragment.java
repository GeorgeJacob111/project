package com.example.myproject.ui.addchild_page;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.myproject.databinding.AddChildPageFragmentBinding;
import com.example.myproject.ui.addchild.addchildFragment;
import com.example.myproject.ui.home.HomeViewModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class addChild_pageFragment extends Fragment {

    private AddChildPageFragmentBinding binding;

    FirebaseDatabase database;
    FirebaseAuth auth;



    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        AddChildPageViewModel addChildPageViewModel = new ViewModelProvider(this).get(AddChildPageViewModel.class);

        binding = AddChildPageFragmentBinding.inflate(inflater, container, false);
        View root = binding.getRoot();



        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


















        binding.bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(addChild_pageFragment.this.requireContext(), addchildFragment.class));
            }
        });

        binding.bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(addChild_pageFragment.this.requireContext(), addchildFragment.class));
            }
        });

        binding.bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(addChild_pageFragment.this.requireContext(), addchildFragment.class));
            }
        });









        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


}