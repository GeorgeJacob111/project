package com.example.myproject.ui.Logout;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.myproject.MainActivity;
import com.example.myproject.databinding.FragmentGalleryBinding;
import com.example.myproject.databinding.LogoutFragmentBinding;
import com.example.myproject.login;
import com.example.myproject.ui.gallery.GalleryViewModel;
import com.google.firebase.auth.FirebaseAuth;

public class LogoutFragment extends Fragment {

    private LogoutFragmentBinding binding;
    FirebaseAuth auth;


    public static LogoutFragment newInstance() {
        return new LogoutFragment();
    }

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        LogoutViewModel logoutViewModel = new ViewModelProvider(this).get(LogoutViewModel.class);

        binding = LogoutFragmentBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        auth = FirebaseAuth.getInstance();
        final TextView textView = binding.textlogout2;
        binding.Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                auth.signOut();

                Intent intent = new Intent(LogoutFragment.this.requireContext(), login.class);
                startActivity(intent);
                //startActivity(new Intent(Logout_Fragment.this,login.class));
            }
        });



        logoutViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}