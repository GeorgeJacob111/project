package com.example.myproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.myproject.models.users;
import com.example.myproject.ui.Logout.LogoutFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity {

    //firebase connection
    FirebaseDatabase database;
    FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar a=getSupportActionBar();
        a.setTitle("Live Location");


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.setboundary:
                Toast.makeText(this, "livelocation", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(this,final_set_location.class);
                startActivity(i);
                return true;



            case R.id.addchild:
                Toast.makeText(this, "addchild", Toast.LENGTH_SHORT).show();
                Intent j = new Intent(this,final_addchild.class);
                startActivity(j);
                return true;

            case R.id.settings:
                Toast.makeText(this, "settings", Toast.LENGTH_SHORT).show();
                Intent k = new Intent(this,settings.class);
                startActivity(k);
                return true;

            case R.id.logout:
                Toast.makeText(this, "Logout Sucessfull", Toast.LENGTH_SHORT).show();
                auth = FirebaseAuth.getInstance();
                auth.signOut();
                Intent intent = new Intent(MainActivity.this, login.class);
                startActivity(intent);

                return true;

            case R.id.help:
                Toast.makeText(this, "help", Toast.LENGTH_SHORT).show();
                Intent l = new Intent(this,help.class);
                startActivity(l);
                return true;

            default:
                return super.onOptionsItemSelected(item);
            //throw new IllegalStateException("Unexpected value: " + item.getItemId());
        }
    }
}