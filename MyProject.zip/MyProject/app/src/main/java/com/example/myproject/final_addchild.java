package com.example.myproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myproject.models.users;
import com.example.myproject.ui.child_reg;
import com.example.myproject.ui.home.HomeFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class final_addchild extends AppCompatActivity {

    //firebase connection
    FirebaseDatabase database;
    FirebaseAuth auth;
    DatabaseReference reference;

    String id;
    TextView t4,t5,c1,c2,c3;
    Button t2,t1,t3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_addchild);
        ActionBar a=getSupportActionBar();
        a.setTitle("Add Child");
        //firebase connection
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        try {
          id  = String.valueOf(auth.getUid());
        } catch (Exception e) {
            e.printStackTrace();
        }
        t4 = findViewById(R.id.text_view_child4);
        t5 = findViewById(R.id.text_view_child5);
        c1 = findViewById(R.id.text_view_child1);
        c2 = findViewById(R.id.text_view_child2);
        c3 = findViewById(R.id.text_view_child3);

        t1 = findViewById(R.id.bt_1);
        t2 = findViewById(R.id.bt_2);
        t3 = findViewById(R.id.bt_3);

        //t4.setText(id);

        String schild1,schild2,schild3;
        //getsharedpreference2
        SharedPreferences sharedPreferences = getSharedPreferences("child",MODE_PRIVATE);
        schild1 = sharedPreferences.getString("child1","");
        schild2 = sharedPreferences.getString("child2","");
        schild3 = sharedPreferences.getString("child3","");


        //sucessfull
        reference = FirebaseDatabase.getInstance().getReference().child("users").child(id);


        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String name = snapshot.child("username").getValue().toString();
                String child1="0",child2="0",child3="0",mail1="0",mail2="0",mail3="0";
                Toast.makeText(final_addchild.this, "."+schild1, Toast.LENGTH_SHORT).show();
                if(schild1 !="0"){
                    child1 = snapshot.child("child").child("1").child("username").getValue().toString();
                    mail1 = snapshot.child("child").child("1").child("mail").getValue().toString();
                }
                if(schild2 !="0"){
                    child2 = snapshot.child("child").child("2").child("username").getValue().toString();
                    mail2 = snapshot.child("child").child("2").child("mail").getValue().toString();
                }
                if(schild3 != "0"){
                    child3 = snapshot.child("child").child("3").child("username").getValue().toString();
                    mail3 = snapshot.child("child").child("3").child("mail").getValue().toString();
                }
                if(!name.isEmpty()){
                    t5.setText("Parent : "+name);
                }
                if(child1!="0"){
                  c1.setText(child1+" : "+mail1);
                  t1.setText("Edit");
                }
                if(child2!="0"){
                    c2.setText(child2+" : "+mail2);
                    t2.setText("Edit");
                }
                if(child3!="0"){
                    c3.setText(child3+" : "+mail3);
                    t3.setText("Edit");
                }

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        //button1
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(final_addchild.this, final_register_child.class);
                i.putExtra("order","1");
                startActivity(i);
            }
        });


        //button2
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(final_addchild.this,final_register_child.class);
                i.putExtra("order","2");
                startActivity(i);
            }
        });



        //button3
        t3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(final_addchild.this,final_register_child.class);
                i.putExtra("order","3");
                startActivity(i);
            }
        });



    }
}