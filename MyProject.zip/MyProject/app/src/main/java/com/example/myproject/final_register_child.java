package com.example.myproject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myproject.models.users;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class final_register_child extends AppCompatActivity {

    EditText username,address,phone,mail,passwd,pincode,landmark,dateofbirth;
    Button childRegister;
    String inusername,inaddress,inphone,inmail,inpasswd,inpincode,inlandmark,indateofbirth;
    String id1;

    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_register_child);
        getSupportActionBar().hide();

        String order = getIntent().getStringExtra("order");

        username = findViewById(R.id.Username);
        mail = findViewById(R.id.Email);
        passwd = findViewById(R.id.Password);
        address = findViewById(R.id.Address);
        phone = findViewById(R.id.Phone);
        pincode = findViewById(R.id.Pincode);
        landmark = findViewById(R.id.Landmark);
        dateofbirth = findViewById(R.id.Dateofbirth);

        //buttons
        childRegister = findViewById(R.id.Register);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        id1 = auth.getUid();

        SharedPreferences sharedPreferences = getSharedPreferences("mineid",MODE_PRIVATE);
        String sharedid = sharedPreferences.getString("userid","");
        String sharedmail = sharedPreferences.getString("usermail","");
        String sharedpassword = sharedPreferences.getString("userpassword","");



        childRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                FirebaseAuth auth;
                FirebaseDatabase database;

                auth = FirebaseAuth.getInstance();
                database = FirebaseDatabase.getInstance();

                inusername = username.getText().toString().trim();
                inmail = mail.getText().toString().trim();
                inpasswd = passwd.getText().toString().trim();
                inaddress = address.getText().toString().trim();
                inphone = phone.getText().toString().trim();
                inpincode = pincode.getText().toString().trim();
                inlandmark = landmark.getText().toString().trim();
                indateofbirth = dateofbirth.getText().toString().trim();
                Toast.makeText(final_register_child.this, "user"+inusername+" mail"+inmail+" password"+inpasswd+" address"+inaddress+" phone"+inphone+" pin"+inpincode+" landmark"+inlandmark+" dateofbirth"+indateofbirth, Toast.LENGTH_SHORT).show();

                if (TextUtils.isEmpty(inusername) || inusername.length() < 3)
                { username.setError("Username must be of 3 or more character");
                    Toast.makeText(final_register_child.this, "Invalid Username", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(inaddress) || inaddress.length() < 10) {
                    address.setError("Enter a valid address");
                    Toast.makeText(final_register_child.this, "Invalid address", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(inphone) || inphone.length() < 10) {
                    phone.setError("Enter a valid phone number");
                    Toast.makeText(final_register_child.this, "Invalid phone", Toast.LENGTH_SHORT).show();
                }
                else if (!validateEmail(mail, getString(R.string.lbl_null_value), getString(R.string.lbl_invalid_value))) {
                    Toast.makeText(final_register_child.this, "Invalid mail", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(inpasswd) || inpasswd.length() < 6) {
                    passwd.setError("password should contain 6 or more character");
                    Toast.makeText(final_register_child.this, "Invalid password", Toast.LENGTH_SHORT).show();
                }else if (TextUtils.isEmpty(inpincode) || inpincode.length() < 6) {
                    pincode.setError("enter a valid pincode");
                    Toast.makeText(final_register_child.this, "Invalid pincode", Toast.LENGTH_SHORT).show();
                }else if (TextUtils.isEmpty(inlandmark) || inlandmark.length() < 3) {
                    landmark.setError("Enter a valid landmark");
                    Toast.makeText(final_register_child.this, "Invalid landmark", Toast.LENGTH_SHORT).show();
                }else if (TextUtils.isEmpty(indateofbirth) || indateofbirth.length() < 10) {
                    dateofbirth.setError("Enter a valid DOB");
                    Toast.makeText(final_register_child.this, "Invalid DateOfBirth", Toast.LENGTH_SHORT).show();
                }
                {
                    Toast.makeText(final_register_child.this, "all set", Toast.LENGTH_SHORT).show();
                    final Task<AuthResult> authResultTask = auth.createUserWithEmailAndPassword(inmail, inpasswd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            //database user creation
                            int v = Integer.parseInt(order);
                            String status = "";
                            status = "2";
                            String id = Objects.requireNonNull(Objects.requireNonNull(task.getResult()).getUser()).getUid();
                            users user = new users(inusername, inmail, inpasswd, id, status, inaddress, inphone, inpincode, inlandmark, indateofbirth);
                            Toast.makeText(final_register_child.this, "id : " + id, Toast.LENGTH_SHORT).show();
                            database.getReference().child("users").child(id1).child("child").child(order).setValue(user);

                            database.getReference().child("child_parent").child(id).child("id").setValue(id);
                            database.getReference().child("child_parent").child(id).child("parent").setValue(id1);
                            database.getReference().child("child_parent").child(id).child("profile").setValue("0");

                            //sharedpreference2
                            SharedPreferences sharedPreferences = getSharedPreferences("child",MODE_PRIVATE);
                            SharedPreferences.Editor mine2 = sharedPreferences.edit();
                            if(v == 1){
                                Toast.makeText(final_register_child.this, "."+v, Toast.LENGTH_SHORT).show();
                                mine2.putString("child1","child1added");
                            }
                            if(v == 2){
                                Toast.makeText(final_register_child.this, "."+v, Toast.LENGTH_SHORT).show();
                                mine2.putString("child2","child2added");
                            }
                            if(v == 3){
                                Toast.makeText(final_register_child.this, "."+v, Toast.LENGTH_SHORT).show();
                                mine2.putString("child3","child3added");
                            }
                            mine2.apply();

                            Toast.makeText(final_register_child.this, "User Created "+order, Toast.LENGTH_SHORT).show();
                        }
                    });


                    auth.signOut();
                    auth.signInWithEmailAndPassword(sharedmail,sharedpassword);

                    Toast.makeText(final_register_child.this,"second time ",Toast.LENGTH_LONG).show();


                    startActivity(new Intent(final_register_child.this, MainActivity.class));
                }
            }
        });
    }

    private boolean validateEmail(EditText p_editText, String p_nullMsg, String p_invalidMsg) {
        boolean m_isValid = false;
        try {
            if (p_editText != null) {
                if (validateForNull(p_editText, p_nullMsg)) {
                    Pattern m_pattern = Pattern.compile("([\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Za-z]{2,4})");
                    Matcher m_matcher = m_pattern.matcher(p_editText.getText().toString().trim());
                    if (!m_matcher.matches() & p_editText.getText().toString().trim().length() > 0) {
                        m_isValid = false;
                        p_editText.setError(p_invalidMsg);
                    } else {
                        m_isValid = true;
                    }
                } else {
                    m_isValid = false;
                }
            } else {
                m_isValid = false;
            }
        } catch (Throwable p_e) {
            p_e.printStackTrace();
        }
        return m_isValid;
    }

    private boolean validateForNull(EditText p_editText, String p_nullMsg) {
        boolean m_isValid = false;
        try {
            if (p_editText != null && p_nullMsg != null) {
                if (TextUtils.isEmpty(p_editText.getText().toString().trim())) {
                    p_editText.setError(p_nullMsg);
                    m_isValid = false;
                } else {
                    m_isValid = true;
                }
            }
        } catch (Throwable p_e) {
            p_e.printStackTrace();
        }
        return m_isValid;
    }


}