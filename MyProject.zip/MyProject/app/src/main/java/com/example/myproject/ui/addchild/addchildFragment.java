package com.example.myproject.ui.addchild;

import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myproject.R;
import com.example.myproject.Register;
import com.example.myproject.databinding.AddchildFragmentBinding;
import com.example.myproject.databinding.FragmentHomeBinding;
import com.example.myproject.models.users;
import com.example.myproject.navigatecenter;
import com.example.myproject.ui.home.HomeViewModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.lifecycle.ViewModelProvider;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class addchildFragment extends Fragment {

    private AddchildFragmentBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        AddchildViewModel addchildViewModel = new ViewModelProvider(this).get(AddchildViewModel.class);

        binding = AddchildFragmentBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //final TextView textView = binding.addchild;
        //addchildViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);


        binding.childRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String inusername,inaddress,inphone,inmail,inpasswd,inpincode,inlandmark,indateofbirth;

                FirebaseAuth auth;
                FirebaseDatabase database;

                auth = FirebaseAuth.getInstance();
                database = FirebaseDatabase.getInstance();

                inusername = binding.Username.getText().toString().trim();
                inmail = binding.Email.getText().toString().trim();
                inpasswd = binding.Password.getText().toString().trim();
                inaddress = binding.Address.getText().toString().trim();
                inphone = binding.Phone.getText().toString().trim();
                inpincode = binding.Pincode.getText().toString().trim();
                inlandmark = binding.Landmark.getText().toString().trim();
                indateofbirth = binding.Dateofbirth.getText().toString().trim();
                Toast.makeText(addchildFragment.this.requireContext(), "user"+inusername+" mail"+inmail+" password"+inpasswd+" address"+inaddress+" phone"+inphone+" pin"+inpincode+" landmark"+inlandmark+" dateofbirth"+indateofbirth, Toast.LENGTH_SHORT).show();

                if (TextUtils.isEmpty(inusername) || inusername.length() < 3)
                { binding.Username.setError("username must be of 3 or more character");
                    Toast.makeText(addchildFragment.this.requireContext(), "Registerion failed username", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(inaddress) || inaddress.length() < 10) {
                    binding.Address.setError("Enter a valid address");
                    Toast.makeText(addchildFragment.this.requireContext(), "Registerion failed address", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(inphone) || inphone.length() < 10) {
                    binding.Phone.setError("Enter a valid phone number");
                    Toast.makeText(addchildFragment.this.requireContext(), "Registerion failed phone", Toast.LENGTH_SHORT).show();
                }
                else if (!validateEmail(binding.Email, getString(R.string.lbl_null_value), getString(R.string.lbl_invalid_value))) {
                    Toast.makeText(addchildFragment.this.requireContext(), "Registerion failed mail", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(inpasswd) || inpasswd.length() < 6) {
                    binding.Password.setError("password should contain 6 or more character");
                    Toast.makeText(addchildFragment.this.requireContext(), "Registerion failed password", Toast.LENGTH_SHORT).show();
                }else if (TextUtils.isEmpty(inpincode) || inpincode.length() < 6) {
                    binding.Pincode.setError("enter a valid pincode");
                    Toast.makeText(addchildFragment.this.requireContext(), "Registerion failed pincode", Toast.LENGTH_SHORT).show();
                }else if (TextUtils.isEmpty(inlandmark) || inlandmark.length() < 3) {
                    binding.Landmark.setError("Enter a valid landmark");
                    Toast.makeText(addchildFragment.this.requireContext(), "Registerion failed landmark", Toast.LENGTH_SHORT).show();
                }else if (TextUtils.isEmpty(indateofbirth) || indateofbirth.length() < 10) {
                    binding.Dateofbirth.setError("Enter a valid DOB");
                    Toast.makeText(addchildFragment.this.requireContext(), "Registerion failed DateOfBirth", Toast.LENGTH_SHORT).show();
                }
                {
                    Toast.makeText(addchildFragment.this.requireContext(), "all set", Toast.LENGTH_SHORT).show();
                    final Task<AuthResult> authResultTask = auth.createUserWithEmailAndPassword(inmail, inpasswd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            //database user creation
                            String status = "";
                            status = "2";
                            String id = Objects.requireNonNull(Objects.requireNonNull(task.getResult()).getUser()).getUid();
                            users user = new users(inusername, inmail, inpasswd, id, status, inaddress, inphone, inpincode, inlandmark, indateofbirth);
                            Toast.makeText(addchildFragment.this.requireContext(), "id : " + id, Toast.LENGTH_SHORT).show();
                            database.getReference().child("users").child(id).setValue(user);

                            Toast.makeText(addchildFragment.this.requireContext(), "User Created", Toast.LENGTH_SHORT).show();
                        }
                    });
                    startActivity(new Intent(addchildFragment.this.requireContext(), navigatecenter.class));
                }















            }
        });


        return root;
    }

    private boolean validateEmail(EditText p_editText, String p_nullMsg, String p_invalidMsg) {
        boolean m_isValid = false;
        try {
            if (p_editText != null) {
                if (validateForNull(p_editText, p_nullMsg)) {
                    Pattern m_pattern = Pattern.compile("([\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Za-z]{2,4})");
                    Matcher m_matcher = m_pattern.matcher(p_editText.getText().toString().trim());
                    if (!m_matcher.matches() & p_editText.getText().toString().trim().length() > 0) {
                        m_isValid = false;
                        p_editText.setError(p_invalidMsg);
                    } else {
                        m_isValid = true;
                    }
                } else {
                    m_isValid = false;
                }
            } else {
                m_isValid = false;
            }
        } catch (Throwable p_e) {
            p_e.printStackTrace();
        }
        return m_isValid;
    }

    private boolean validateForNull(EditText p_editText, String p_nullMsg) {
        boolean m_isValid = false;
        try {
            if (p_editText != null && p_nullMsg != null) {
                if (TextUtils.isEmpty(p_editText.getText().toString().trim())) {
                    p_editText.setError(p_nullMsg);
                    m_isValid = false;
                } else {
                    m_isValid = true;
                }
            }
        } catch (Throwable p_e) {
            p_e.printStackTrace();
        }
        return m_isValid;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}