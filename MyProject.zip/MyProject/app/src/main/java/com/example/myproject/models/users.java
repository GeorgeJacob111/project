package com.example.myproject.models;

public class users {
    String profilePic, username, mail, password, userId, lastmessage, status,address,phone,pincode,landmark,datofbirth;

    public users()
    {

    }

    public users(String profilePic, String username, String mail, String password, String userId, String lastmessage, String status) {
        this.profilePic = profilePic;
        this.username = username;
        this.mail = mail;
        this.password = password;
        this.userId = userId;
        this.lastmessage = lastmessage;
        this.status = status;
    }

    public users(String username, String mail, String password) {
        this.username = username;
        this.mail = mail;
        this.password = password;
    }

    public users(String username, String mail, String password, String userId, String status, String address, String phone, String pincode, String landmark, String datofbirth) {
        this.username = username;
        this.mail = mail;
        this.password = password;
        this.userId = userId;
        this.status = status;
        this.address = address;
        this.phone = phone;
        this.pincode = pincode;
        this.landmark = landmark;
        this.datofbirth = datofbirth;
    }



    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLastmessage() {
        return lastmessage;
    }

    public void setLastmessage(String lastmessage) {
        this.lastmessage = lastmessage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getDatofbirth() {
        return datofbirth;
    }

    public void setDatofbirth(String datofbirth) {
        this.datofbirth = datofbirth;
    }
}
