package com.example.child;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    EditText mail,passwd ;
    Button Login;
    String inmail, inpasswd;


    //firebase connection
    FirebaseDatabase database;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mail = findViewById(R.id.email);
        passwd = findViewById(R.id.password);
        Login = findViewById(R.id.Login);


        //firebase connection
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        getSupportActionBar().hide();

        if(auth.getCurrentUser() != null)
        {
            startActivity(new Intent(MainActivity.this,home.class));
            finish();
        }



        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                inmail = mail.getText().toString().trim();
                inpasswd = passwd.getText().toString().trim();


                if (!validateEmail(mail, getString(R.string.lbl_null_value), getString(R.string.lbl_invalid_value)))
                {
                    mail.setError("password should contain 6 or more character");
                    Toast.makeText(MainActivity.this, "Invalid mail/password", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(inpasswd) || inpasswd.length() < 6)
                {
                    passwd.setError("password should contain 6 or more character");
                    Toast.makeText(MainActivity.this, "Invalid mail/password", Toast.LENGTH_SHORT).show();
                }
                else {
                    auth.signInWithEmailAndPassword(inmail,inpasswd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                Toast.makeText(MainActivity.this, "SignIn Sucessfull", Toast.LENGTH_SHORT).show();
                                //for id
                                String id = task.getResult().getUser().getUid();
                                //shared preference
                                SharedPreferences sharedPreferences = getSharedPreferences("mineid",MODE_PRIVATE);
                                SharedPreferences.Editor mine = sharedPreferences.edit();
                                mine.putString("userid",id);
                                mine.putString("usermail",inmail);
                                mine.putString("userpassword",inpasswd);
                                mine.apply();

                                startActivity(new Intent(getApplicationContext(),home.class));
                                finish();
                            }
                            else
                            {
                                Toast.makeText(MainActivity.this, "password/email is invalid", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

            }
        });

    }

    private boolean validateEmail(EditText p_editText, String p_nullMsg, String p_invalidMsg) {
        boolean m_isValid = false;
        try {
            if (p_editText != null) {
                if (validateForNull(p_editText, p_nullMsg)) {
                    Pattern m_pattern = Pattern.compile("([\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Za-z]{2,4})");
                    Matcher m_matcher = m_pattern.matcher(p_editText.getText().toString().trim());
                    if (!m_matcher.matches() & p_editText.getText().toString().trim().length() > 0) {
                        m_isValid = false;
                        p_editText.setError(p_invalidMsg);
                    } else {
                        m_isValid = true;
                    }
                } else {
                    m_isValid = false;
                }
            } else {
                m_isValid = false;
            }
        } catch (Throwable p_e) {
            p_e.printStackTrace();
        }
        return m_isValid;
    }

    private boolean validateForNull(EditText p_editText, String p_nullMsg) {
        boolean m_isValid = false;
        try {
            if (p_editText != null && p_nullMsg != null) {
                if (TextUtils.isEmpty(p_editText.getText().toString().trim())) {
                    p_editText.setError(p_nullMsg);
                    m_isValid = false;
                } else {
                    m_isValid = true;
                }
            }
        } catch (Throwable p_e) {
            p_e.printStackTrace();
        }
        return m_isValid;
    }

}