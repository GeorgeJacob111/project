package com.example.child;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class home extends AppCompatActivity {
    FirebaseDatabase database;
    FirebaseAuth auth;
    Button help ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ActionBar a=getSupportActionBar();
        a.setTitle("Home");







    }

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.settings:
                Toast.makeText(this, "settings", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(home.this,settings.class);
                startActivity(i);
                return true;



            case R.id.help:
                Toast.makeText(this, "addchild", Toast.LENGTH_SHORT).show();
                Intent j = new Intent(home.this,help.class);
                startActivity(j);
                return true;



            case R.id.logout:
                auth = FirebaseAuth.getInstance();
                auth.signOut();
                Toast.makeText(this, "Logout Sucessfull", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(home.this, MainActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
            //throw new IllegalStateException("Unexpected value: " + item.getItemId());
        }
    }

}